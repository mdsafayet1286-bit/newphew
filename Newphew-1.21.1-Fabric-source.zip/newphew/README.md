# Newphew (Fabric 1.21.1) — by Esy

Adds 5 music discs, each found in a different place (30% chance per chest):

| Disc  | Where to find it        | Song id (in lang file) |
|-------|-------------------------|------------------------|
| One   | Desert Pyramid chests   | Esy - Desert Whispers  |
| Two   | Ancient City chests     | Esy - Deep Echoes      |
| Three | Bastion Treasure chests | Esy - Piglin Groove    |
| Four  | End City treasure chests| Esy - Void Drift       |
| Five  | Woodland Mansion chests | Esy - Mansion Waltz    |

## Replace the placeholder sounds
Overwrite these files with your own `.ogg` (Vorbis, mono recommended):
`src/main/resources/assets/newphew/sounds/music_disc/disc_one.ogg` ... `disc_five.ogg`

Also update the song length (seconds) in
`src/main/resources/data/newphew/jukebox_song/disc_<name>.json` -> `length_in_seconds`
and the display names in `assets/newphew/lang/en_us.json`.

## Build
Requires JDK 21.
    gradle wrapper --gradle-version 8.10   (once, if you have Gradle installed)
    ./gradlew build
The jar appears in `build/libs/newphew-1.0.0.jar` — put it in `.minecraft/mods` with Fabric Loader 0.16+ and Fabric API 0.105.0+1.21.1.
Or just open the folder in IntelliJ IDEA as a Gradle project and run the `build` task.

Get a disc in-game: `/give @s newphew:music_disc_one`
