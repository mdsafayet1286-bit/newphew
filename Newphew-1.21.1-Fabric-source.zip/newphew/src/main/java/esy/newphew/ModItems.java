package esy.newphew;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.item.JukeboxSong;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class ModItems {
    public static final Item MUSIC_DISC_ONE = disc("one");
    public static final Item MUSIC_DISC_TWO = disc("two");
    public static final Item MUSIC_DISC_THREE = disc("three");
    public static final Item MUSIC_DISC_FOUR = disc("four");
    public static final Item MUSIC_DISC_FIVE = disc("five");

    public static final ItemGroup NEWPHEW_GROUP = Registry.register(
            Registries.ITEM_GROUP,
            Identifier.of(Newphew.MOD_ID, "newphew"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(MUSIC_DISC_ONE))
                    .displayName(Text.translatable("itemGroup.newphew"))
                    .entries((ctx, entries) -> {
                        entries.add(MUSIC_DISC_ONE);
                        entries.add(MUSIC_DISC_TWO);
                        entries.add(MUSIC_DISC_THREE);
                        entries.add(MUSIC_DISC_FOUR);
                        entries.add(MUSIC_DISC_FIVE);
                    })
                    .build());

    private static Item disc(String name) {
        RegistryKey<JukeboxSong> song = RegistryKey.of(
                RegistryKeys.JUKEBOX_SONG, Identifier.of(Newphew.MOD_ID, "disc_" + name));
        return Registry.register(
                Registries.ITEM,
                Identifier.of(Newphew.MOD_ID, "music_disc_" + name),
                new Item(new Item.Settings().maxCount(1).rarity(Rarity.RARE).jukeboxPlayable(song)));
    }

    public static void register() {}
}
