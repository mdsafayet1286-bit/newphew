package esy.newphew;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;

import java.util.Map;

/** Each disc is found in a different vanilla structure chest. */
public class ModLoot {
    private static final float CHANCE = 0.30f;

    public static void register() {
        Map<Identifier, Item> sources = Map.of(
                Identifier.ofVanilla("chests/desert_pyramid"), ModItems.MUSIC_DISC_ONE,
                Identifier.ofVanilla("chests/ancient_city"), ModItems.MUSIC_DISC_TWO,
                Identifier.ofVanilla("chests/bastion_treasure"), ModItems.MUSIC_DISC_THREE,
                Identifier.ofVanilla("chests/end_city_treasure"), ModItems.MUSIC_DISC_FOUR,
                Identifier.ofVanilla("chests/woodland_mansion"), ModItems.MUSIC_DISC_FIVE
        );

        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            Item disc = sources.get(key.getValue());
            if (disc != null && source.isBuiltin()) {
                tableBuilder.pool(LootPool.builder()
                        .rolls(ConstantLootNumberProvider.create(1))
                        .conditionally(RandomChanceLootCondition.builder(CHANCE))
                        .with(ItemEntry.builder(disc)));
            }
        });
    }
}
