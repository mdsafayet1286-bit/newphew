package esy.newphew;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    // Sound files live in: assets/newphew/sounds/music_disc/disc_<name>.ogg
    // Replace them with your own .ogg (mono recommended, Vorbis codec).
    public static final SoundEvent DISC_ONE = register("music_disc.disc_one");
    public static final SoundEvent DISC_TWO = register("music_disc.disc_two");
    public static final SoundEvent DISC_THREE = register("music_disc.disc_three");
    public static final SoundEvent DISC_FOUR = register("music_disc.disc_four");
    public static final SoundEvent DISC_FIVE = register("music_disc.disc_five");

    private static SoundEvent register(String name) {
        Identifier id = Identifier.of(Newphew.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {}
}
