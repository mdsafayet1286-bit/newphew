package esy.newphew;

import net.fabricmc.api.ModInitializer;

public class Newphew implements ModInitializer {
    public static final String MOD_ID = "newphew";

    @Override
    public void onInitialize() {
        ModSounds.register();
        ModItems.register();
        ModLoot.register();
    }
}
